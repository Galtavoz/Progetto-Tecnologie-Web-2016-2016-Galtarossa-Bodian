<?php

	include("sopra.html");
	include("home.html");
	include("sotto.html");
?>

<html>
	<head>
		<title>Admin Logon</title>
		
		<meta http-equiv='Content-Type' content='text/html;charset=ISO-8859-15'/>
		
		<link type="text/css" href="./css/css.css" rel="stylesheet"/>
		
	</head>
	<body>
		<div id="login">
			<form method="POST" action="second.php" class="loginForm">
				<h2 class="ridimensiona">Effettua il login</h2>
				<input class="inputform" id="firstinput" type="text" name="user" placeholder="Username" /></br>
				<input class="inputform" id="secondinput" type="password" name="pass" placeholder="Password" /></br>
				<input class="submitform" type="submit" value="Login" />
			</form>
		</div>
	</body>
</html>